from setuptools import setup, find_packages

setup(
    name="com.rtx.fossboss",
    version='0.0.1',
    author='Adam Long',
    author_email='adam.j.long@rtx.com',
    description='_FossBoss_ provides the means and methods for automating FOSS Management tasks.',
    long_description=open('README.md').read(),
    long_description_content_type="text/markdown",
    url="https://g019-bitbucket.mcah.usdcag.aws.ray.com/projects/MDAFB/repos/fossboss/browse",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    include_package_data=True,
    package_data={
        '':['LICENSE'],
        'com.rtx.fossboss.formatters': [
            'templates/metrics-template.html.j2',
            'templates/msf-notification-template.html.j2'
        ],
        'com.rtx.fossboss.retrievers': [
            'jinja_templates/npmrc.j2'
        ]
    },
    install_requires=[
        'certifi==2024.2.2',
        'charset-normalizer==3.3.2',
        'idna==3.7',
        'requests==2.31.0',
        'urllib3==2.2.1',
        'dohq-artifactory==0.10.0',
        'wheel==0.40.0',
        'jinja2==3.1.3',
        'version-parser==1.0.1'
    ],
    classifiers=[
        'Deployment Environment :: Development',
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Topic :: Software Development',
        'License :: RTX',
        'Programming Language :: Python :: 3.11',
    ],
) 
