# FossBoss
_FossBoss_ is intended to be a comprehensive FOSS Management library. _FossBoss_ is built to serve three main functions:
* Ease the burden of FOSS submittals
* Proactively seek updated vulnerability scans (Future)
* Proactively seek updated versions of libraies (Future)

_FossBoss_ is part of MSF's Domain Assets and is publically available for anyone who wishes to simplify their FOSS management. All the functionality and entry points are built for flexibility and configurability.

### Setup Instructions  
Setup a python virtual environment to run in.
```console
python3.11 -m venv .venv
source .venv/bin/activate
pip install .
```

## Easing the burden of FOSS submittals (BountyHunter)
_FossBoss' BountyHunter_ eases the burden of FOSS submittals by providing a set of utility functions that interact with Raytheon's FOSS ES / Lighthouse solution. When a developer or FOSS manager submits a FOSS request via _BountyHunter_, the _BountyHunter_ locates all the dependencies associated with the requested product and then submits an entry for each one so that the requester only needs to worry about the high level artifacts. Once artifacts are requested through FOSS ES / Lighthouse, they are automatically uploaded into either the a trusted or untrusted repository. Once available in the repository developers can utilize the artifacts through their standard build tools, thus they have collected the reward/bounty. 

##### Limitations
_FossBoss's BountyHunter_ is currently limited to automating FOSS submittals for Maven, PyPI, and NPM. Furthermore, it is limited to interacting with Artifactory though the hooks are in place to allow it to be easily extended to add support for Sonatype Nexus.

### Execution Examples
_Note:_ The following examples are largely associated to MSF, however the user and token have been change to comply with standard security policies. If you are a program looking to utilize _FossBoss's BountyHunter_ for your own needs, you'll also need to change the URLs of the repositories.

#### Getting Started
Get a list of all the parameters and options available.
```console
python -m com.rtx.fossboss.bountyhunter --help
```

#### Submitting Software Requests
```console
python -m com.rtx.fossboss.bountyhunter \
-t maven \
-g org.springframework.boot \
-a spring-boot \
-v 3.2.5 \
-u wade_wilson \
-tk chimichangas \
-lr https://g019-artifactory.mcah.usdcag.aws.ray.com/artifactory/ris-keystone-internal-maven-remote/ \
-ptr https://g019-artifactory.mcah.usdcag.aws.ray.com/artifactory/msf-maven-external-local/ \
-pur https://g019-artifactory.mcah.usdcag.aws.ray.com/artifactory/msf-maven-untrusted-local/ \
-of json
```
```console
python -m com.rtx.fossboss.bountyhunter \
-t npm \
-a express \
-v 4.17.1 \
-u wade_wilson \
-tk chimichangas \
-lr https://g019-artifactory.mcah.usdcag.aws.ray.com/artifactory/ris-keystone-internal-npm-remote/ \
-ptr https://g019-artifactory.mcah.usdcag.aws.ray.com/artifactory/msf-npm-external-local/ \
-pur https://g019-artifactory.mcah.usdcag.aws.ray.com/artifactory/msf-npm-untrusted-local/ \
-of html
```
```console
python -m com.rtx.fossboss.bountyhunter \
-t pypi \
-a requests \
-v 2.31.0 \
-u wade_wilson \
-tk chimichangas \
-lr https://g019-artifactory.mcah.usdcag.aws.ray.com/artifactory/ris-keystone-internal-pypi-remote/ \
-ptr https://g019-artifactory.mcah.usdcag.aws.ray.com/artifactory/msf-pypi-external-local/ \
-pur https://g019-artifactory.mcah.usdcag.aws.ray.com/artifactory/msf-pypi-untrusted-local/ \
-of json
```

## Maintainer
Maintained by Raytheon's Modern Software Factory.

## License
Copyright ©, Raytheon Company

More licensing information can be found [here](./LICENSE).
