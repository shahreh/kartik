# RAYTHEON PROPRIETARY
# This document contains data or information proprietary to Raytheon Company
# and is restricted to use only by persons authorized by Raytheon Company in
# writing to use it. Disclosure to unauthorized persons would likely cause
# substantial competitive harm to Raytheon Company's business position.
# Neither said document nor its contents shall be furnished or disclosed to or
# copied or used by persons outside Raytheon Company without the express
# written approval of Raytheon Company.
# 
# Unpublished Work - Copyright Raytheon Company

import shutil

from com.rtx.fossboss.locators._locator import Locator
from com.rtx.fossboss.publishers._publisher import Publisher

class Retriever:

    def __init__ (self, artifact_group: str, artifact_name: str, artifact_version: str, 
                  public_repo: str, lighthouse_repo: str, program_trusted_repo: str, 
                  program_untrusted_repo: str, staging_dir: str, locator:Locator, 
                  publisher:Publisher, user:str, token:str, proxy_host:str, proxy_port:int,
                  ca_bundle:str):
        
        self.artifact_group = artifact_group
        self.artifact_name = artifact_name
        self.artifact_version = artifact_version
        self.public_repo = public_repo
        self.lighthouse_repo = lighthouse_repo
        self.program_trusted_repo = program_trusted_repo
        self.program_untrusted_repo = program_untrusted_repo
        self.staging_dir = staging_dir
        self.locator = locator
        self.publisher = publisher
        self.user = user
        self.token = token
        self.proxy_host = proxy_host
        self.proxy_port = proxy_port
        self.ca_bundle = ca_bundle

        self.artifacts = {}

    def generate_inventory(self):
        """
        Identifies all the dependencies of the desired artifact. At the close of this function, 
        self.artfacts will have a complete listing of artifacts that will need to be submitted 
        to Lighthouse/FOSS ES.
        """
        raise NotImplementedError("Technology specific retrievers must implement this method")

    def retrieve_from_internet(self):
        """
        Retrieves a listing of all artifacts are that are to be submitted to Lighthouse by
        looking at the internet using pre-established trusted repositories (e.g., npmjs.org)
        """
        raise NotImplementedError("Technology specific retrievers must implement this method")
    
    def retrieve_from_lighthouse(self):
        """
        Retrieves artifacts from Lighthouse to determine if they are approved or not approved.
        If a valid respone is returned, the artifact is approved, otherwise it's not approaved.
        """
        raise NotImplementedError("Technology specific retrievers must implement this method")
    
    def upload_artifacts(self, early_access_waiver):
        """
        Uploads artifacts to the program's repositories.

        Args
            early_access_waiver (bool): flag indicating if artifacts can be temporarily uploaded into an untrusted repo (default=True)
        """
        raise NotImplementedError("Technology specific retrievers must implement this method")
    
    def clean(self):
        """
        Cleans up any resources that were created during the process
        """
        shutil.rmtree(self.staging_dir, ignore_errors=True)