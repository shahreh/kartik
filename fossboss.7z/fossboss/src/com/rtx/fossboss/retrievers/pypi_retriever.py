 # RAYTHEON PROPRIETARY
 # This document contains data or information proprietary to Raytheon Company
 # and is restricted to use only by persons authorized by Raytheon Company in
 # writing to use it. Disclosure to unauthorized persons would likely cause
 # substantial competitive harm to Raytheon Company's business position.
 # Neither said document nor its contents shall be furnished or disclosed to or
 # copied or used by persons outside Raytheon Company without the express
 # written approval of Raytheon Company.
 # 
 # Unpublished Work - Copyright Raytheon Company

import glob
import logging as log
import os
import re
import subprocess
from subprocess import CompletedProcess

from com.rtx.fossboss.retrievers._retriever import Retriever

logger = log.getLogger('pypi-retriever-logger')
logger.setLevel(log.ERROR)

class PypiRetriever(Retriever):

    def generate_inventory(self) -> None:
        """
        Gathers info about the requested artifact and its dependencies. 
        Marks each as trusted or untrusted depending if they are in lighthouse.
        """

        result = self.__install_package(f"{self.artifact_name}=={self.artifact_version}", self.public_repo, self.staging_dir, True, True)
        
        for line in result.stdout.splitlines():
            if 'Would install' in line:
                for dependency in line[14:].split(' '):
                    pos = dependency.rfind('-')
                    self.artifacts[f"{dependency[:pos].replace('-','_')}:{dependency[pos + 1:]}"] = {
                            "artifact": dependency[:pos].replace('-','_'),
                            "version": dependency[pos + 1:],
                            "status": 'Needs Requested',
                            "approved": False,
                            "artifacts": []
                        }

        for key, value in self.artifacts.items():
            # If the package is already known to be trusted or untrusted, then mark it as
            # known so that it can be skipped from the downloading process
            available = self.locator.is_artifact_trusted(None, value['artifact'], value['version'], None)
            if len(self.locator.locate_artifact(f"{self.lighthouse_repo.strip('/')}-cache", f"{value['artifact']}-{value['version']}*.whl")) > 0 and available == False:
                self.artifacts[key]['status'] = 'Known: Needs Copied'
                self.artifacts[key]['approved'] = True
            if available == True:
                self.artifacts[key]['status'] = 'Known: Trusted'
                self.artifacts[key]['approved'] = True
            elif self.locator.is_artifact_untrusted(None, value['artifact'], value['version'], None) == True:
                self.artifacts[key]['status'] = 'Known: Untrusted'
        
    def retrieve_from_lighthouse(self) -> None:
        """
        Checks if packages are available in lighthouse and marks them as Requested and conditionally, Approved.
        """
        
        # for each artifact classify as either trusted or untrusted
        for key, artifact in self.artifacts.items():

            # If this artifact is already known in the trusted, then
            # it can be skipped from retrieveing from lighthouse
            # _Note_: untrusted can also be added to this list
            if artifact['status'] in ['Known: Trusted', 'Known: Needs Copied']:
                continue
            
            # It doesn't matter if this is above or below the call to lighthouse as we cannot
            # distinguish errors from lighthouse to know if it actually made it into the 
            # request queue
            self.artifacts[key]['status'] = 'Requested'

            try:
                result = self.__install_package(key.replace(':', '=='), self.lighthouse_repo.replace('://', f"://{self.user}:{self.token}@"), None, False, True)
                if result and result.returncode == 0:
                    self.artifacts[key]['approved'] = True  
            except RuntimeError:
                logger.debug(f"Error trying to install, {key}, from lighthouse, this is to be expected in most cases")
    
    def retrieve_from_internet(self) -> None:
        """
        Gather artifacts from public repo if they are not in already in lighthouse.
        For python, this means downloading the wheel files for the packages. Artifacts will be
        located at the {staging_dir}/inventory/wheels.

        Raises:
            RuntimeError: if the pip wheel subprocess returns non-zero error code 
        """
        
        # wheel files will download to a separate directory
        # setup directory where packages will be installed
        inventory_staging_dir = os.path.join(self.staging_dir, 'inventory')
        os.makedirs(inventory_staging_dir, exist_ok=True)

        wheel_staging_dir = os.path.join(inventory_staging_dir, 'wheels')
        os.makedirs(wheel_staging_dir, exist_ok=True)

        for key, artifact in self.artifacts.items():

            if 'Requested' in artifact['status'] and artifact['approved'] == False:
                
                logger.debug(f"Retrieving {artifact['artifact']} from the internet.")
                
                result = subprocess.run(
                    ['pip', 'wheel', key.replace(':', '=='),
                     '--index-url', self.public_repo,
                     '--wheel-dir', wheel_staging_dir,
                     '--cert', self.ca_bundle], 
                     stdout=subprocess.PIPE,
                     stderr=subprocess.DEVNULL, # suppress the deprecation warnings, no need to process 
                     text=True)
                
                if result.returncode != 0:
                    raise RuntimeError(f"Failed to download wheel for package: {key}")
                else:
                    whl_files = self.__locate_artifacts_in_staging(artifact['artifact'], artifact['version'])
                    self.artifacts[key]['artifacts'] = whl_files

    def upload_artifacts(self, early_access_waiver:bool=True) -> None:
        """
        Upload artifacts to trusted and untrusted repos. 
        Copies from lighthouse where possible, otherwise uploads from downloaded artifacts.

        Args:
            early_access_waiver (bool): software that has not gone thru the FOSS process 
                                        can be moved to an untrusted repo when True
        """

        for artifact in self.artifacts.values():

            if artifact['status'] in ['Requested', 'Known: Needs Copied'] and artifact['approved'] == True:
                # First, do a copy from the cache. Note: if you don't have the -cache it results in an error.
                # This code has a built in assumption that the lighthouse repo is a remote (implies cache)
                matching_artifacts = self.locator.locate_artifact(f"{self.lighthouse_repo.strip('/')}-cache", f"{artifact['artifact']}-{artifact['version']}*.whl")
                logger.debug(f"Mactching artifacts: {matching_artifacts}")
                self.publisher.publish_via_copy_artifacts(self.program_trusted_repo, None, artifact['artifact'], artifact['version'], matching_artifacts)
            elif early_access_waiver == True and (artifact['status'] == 'Requested' and artifact['approved'] == False):
                logger.debug(f"Uploading: {artifact['artifacts']}")
                self.publisher.publish_via_upload(self.program_untrusted_repo, None, artifact['artifact'], artifact['version'], artifact['artifacts'])

    def __install_package(self, package:str, index_url:str, target_dir:str, dependencies:bool, dry_run:bool) -> CompletedProcess:
        """(private)
        Runs pip install to download and install python packages.

        Args:
            package (str): package argument for pip
            index_url (str): repository to pull packages from
            target_dir (str): location where packages will be installed
            dependencies (bool): pulls packages in dependency tree when True
            dry_run (bool): does not persist any artifacts when True

        Returns:
            CompletedProcess: result from running subprocess of pip command

        Raises:
            RuntimeError: if the pip install subprocess returns non-zero error code 
        """

        command = ['pip', 'install', package, '--index-url', index_url, '--cert', self.ca_bundle, '--no-cache-dir']

        if dependencies == False:
            command.append('--no-deps')

        if target_dir:
            command.append('--target')
            command.append(target_dir)

        if dry_run == True:
            command.append('--dry-run')

        # suppress the deprecation warnings, no need to process stderr
        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
            
        if result.returncode != 0:
            raise RuntimeError("Error executing pip install")
        
        return result
    
    def __locate_artifacts_in_staging(self, artifact_name:str, artifact_version:str) -> list[str]:
        """(private)
        Locates artifacts that were retrieved and stored in the inventory.

        Args:
            artifact_name (str): name of the packages as recognized by Pypi
            artifact_version (str): version from the package

        Returns:
            list: all artifacts in the inventory that match *.whl
        """
        
        original_cwd = os.getcwd()
        os.chdir(f"{self.staging_dir}/inventory/wheels")

        # pip treats - and _ as the same, but glob does not; some artifact names come back with - in the name but the
        # wheel file has _ so this needs to consider both cases
        all_whl_paths = glob.glob(f"**/{artifact_name}-{artifact_version}*.whl", recursive=True)

        all_artifacts = [os.path.abspath(file) for file in all_whl_paths]

        os.chdir(original_cwd)

        return all_artifacts