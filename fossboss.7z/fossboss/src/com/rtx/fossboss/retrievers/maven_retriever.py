 # RAYTHEON PROPRIETARY
 # This document contains data or information proprietary to Raytheon Company
 # and is restricted to use only by persons authorized by Raytheon Company in
 # writing to use it. Disclosure to unauthorized persons would likely cause
 # substantial competitive harm to Raytheon Company's business position.
 # Neither said document nor its contents shall be furnished or disclosed to or
 # copied or used by persons outside Raytheon Company without the express
 # written approval of Raytheon Company.
 # 
 # Unpublished Work - Copyright Raytheon Company

import glob
import logging as log
import os
import subprocess

from com.rtx.fossboss.retrievers._retriever import Retriever 
from com.rtx.fossboss.retrievers.exceptions.artifact_not_found_error import ArtifactNotFoundError
from com.rtx.fossboss.retrievers.exceptions.artifact_not_resolvable_error import  ArtifactNotResolvableError

logger = log.getLogger('maven-retriever-logger')
logger.setLevel(log.ERROR)

class MavenRetriever(Retriever):

    def generate_inventory(self):
        """
        Generate an inventory of all the artifacts that are required as part of a FOSS request.
        In the case of Maven, this includes the main jar, the pom file, and the -sources and 
        javadoc jars. This must be recursive to ensure everything is retrieved.
        """

        inventory_staging_dir = f"{self.staging_dir}/inventory"
        project_name = f"{self.artifact_name}-dependency-checker"
        project_dir = os.path.join(inventory_staging_dir, project_name)

        self.__get_dependencies(inventory_staging_dir, project_dir, self.artifact_group, self.artifact_name, self.artifact_version, 'jar')
        self.__process_dependencies()

    def retrieve_from_lighthouse(self):
        """
        Retrieves artifacts from FOSS ES / Lighthouse, which inherently triggers the FOSS submittal. 
        This method utilizes Gradle as the means to request the aritfacts. In many cases, it is 
        expected that the Gradle command will fail because FOSS ES / Lighthouse has not seen the
        requested artifact before. To see items that are failing, you need to enable debug.
        """

        gradle_repository_closure = f"""
        repositories {{

            def secrets = {{
                username System.getenv("username")
                password System.getenv("password")
            }}

            maven {{
                url = '{self.lighthouse_repo}'
                credentials secrets
            }}
        }}"""

        for key, value in self.artifacts.items():

            # If the status states, it needs requested, then create a
            # simple project with that dependency and submit it to lighthouse
            # Always request Known: Untrusted to see if anything changed
            if value['status'] == 'Needs Requested' or value['status'] == 'Known: Untrusted':
                
                lighthouse_staging_dir = f"{self.staging_dir}/lighthouse"
                project_name = f"{value['artifact']}-lighthouse-submitter"
                project_dir = os.path.join(lighthouse_staging_dir, project_name)

                try:
                    self.__execute_gradle(lighthouse_staging_dir, project_dir, gradle_repository_closure, value['group'], value['artifact'], value['version'])
                    self.artifacts[key]['status'] = 'Requested'
                except ArtifactNotFoundError as e:
                    # This error is expected when lighthouse has not seen the artifact before, and 
                    # this implies it has been submitted to lighthouse 
                    self.artifacts[key]['status'] = 'Requested'
                except ArtifactNotResolvableError as e:
                    # This error is not expected and likely means lighthouse is broken, and 
                    # we should not trust that it has been properly requested.
                    self.artifacts[key]['status'] = 'Needs Requested'
                    
                # If the main jar is available we'll consider it a success otherwise a failure
                # pom and other files can be picked up from internet inventory
                artifact_package_name = f"{value['artifact']}-{value['version']}.jar"
                if self.locator.is_artifact_available(self.lighthouse_repo, value['group'], value['artifact'], value['version'], artifact_package_name) == True:
                    self.artifacts[key]['approved'] = True
                    logger.debug(f"Successfully submitted request to FOSS ES / Lighthouse for  {value['artifact']}@{value['version']}")
                else:
                    self.artifacts[key]['approved'] = False
                    logger.info(f"Failed submitting request to FOSS ES / Lighthouse for  {value['artifact']}@{value['version']}")
            else:
                logger.debug(f"Skipping {value['artifact']}@{value['version']} because it has a status of {value['status']}")  
         
    def retrieve_from_internet(self):
        """
        This is a no-op for Maven, but is included to adhere to the interface. The original retrieval of dependencies will
        have already brought down the artifacts that are needed They can found in:
            <staging-dir>/inventory/<artifact>-dependency-checker
        """
        pass

    def upload_artifacts(self, early_access_waiver:bool=True):
        """
        Uploads all the retrieved artifacts to the sepecified trusted and untrusted repositories based on whether or not 
        the artifact was tagged as approved. In the case Maven, it will attempt to copy the artifacts from the -cache to
        the trusted. Any additional artifacts that were retrieved when getting the inventory from the internet will be
        uploaded even if FOSS ES / Lighthouse failed to process them (e.g., -sources and -javadoc)

        Args
            early_access_waiver (bool): flag indicating if artifacts can be temporarily uploaded into an untrusted repo (default=True)
        """

        for artifact in self.artifacts.values():

            if artifact['status'] in ['Requested','Known: Needs Copied'] and artifact['approved'] == True:
                # First, do a copy from the cache. Note: if you don't have the -cache it results in an error.
                # This code has a built in assumption that the lighthouse repo is a remote (implies cache)
                location = self.publisher.publish_via_copy_directory(f"{self.lighthouse_repo.rstrip('/')}-cache", self.program_trusted_repo, artifact['group'], artifact['artifact'], artifact['version'])

                # Second, upload any items that we were able to retrieve from the internet that did not get copied over
                # from lighthouse
                missing_artifacts = []
                for file in artifact['artifacts']:
                    artifact_package_name = os.path.basename(file)
                    if self.locator.is_artifact_available(self.program_trusted_repo, artifact['group'], artifact['artifact'], artifact['version'], artifact_package_name) == False:
                        missing_artifacts.append(file)

                    self.publisher.publish_via_upload(self.program_trusted_repo, artifact['group'], artifact['artifact'], artifact['version'], missing_artifacts)

                artifact['location'] = location
            elif early_access_waiver == True and (artifact['status'] == 'Requested' and artifact['approved'] == False):
                location = self.publisher.publish_via_upload(self.program_untrusted_repo, artifact['group'], artifact['artifact'], artifact['version'], artifact['artifacts'])
                artifact['location'] = location
            
            # If the artifact is known, double check that all the artifacts are uploaded. This will ensure that if the artifact was an older
            # request that only captured the jar or pom we can add in the missing artifacts like poms, -sources.jar, and -javadoc.jar.
            # The publish via upload will log a debug message if the file already exists, so we can just pass in all the collected artifacts
            if artifact['status'] in ['Known: Trusted', 'Known: Needs Copied']:
                location = self.publisher.publish_via_upload(self.program_trusted_repo, artifact['group'], artifact['artifact'], artifact['version'], artifact['artifacts'])
                
    
    def __create_minimal_gradle_project(self, project_dir:str, gradle_repository_closure:str, artifact_group:str, artifact_name:str, artifact_version:str):
        """(private) 
        Creates a basic gralde project on disk that is designed to pull down a specific artifact. 
        This gralde project will also attempt to pull down sources and javadocs.

        Args:
            project_dir (str): directory of the gradle project is to be created
            gradle_repository_closure (str): identifies the location where the aritfact should be retrieved from
            artifact_group (str): group from the Maven GAV parameters
            artifact_name (str): artifact from the Maven GAV parameters
            artifact_version (str): version from the Maven GAV parameters
        """
        
        src_dir = os.path.join(project_dir, 'src', 'main', 'java')

        # Create directories
        os.makedirs(src_dir, exist_ok=True)

        # Create build.gradle content, using injection for the repositories allows
        # this code be more more reusable
        # 
        # Also always attempt to pull own the sources and javadoc as developers can
        # make use of these if they are available
        build_gradle_content = f"""
        plugins {{
            id 'java'
        }}

        {gradle_repository_closure}

        dependencies {{
            implementation '{artifact_group}:{artifact_name}:{artifact_version}'
            implementation '{artifact_group}:{artifact_name}:{artifact_version}:sources'
            implementation '{artifact_group}:{artifact_name}:{artifact_version}:javadoc'
        }}

        task resolveAllDependencies() {{
            doLast {{
                configurations.each {{ config ->
                    if (config.isCanBeResolved()) {{
                        config.resolve()
                    }}
                }}
            }}
        }}

        """

        # Write the build.gradle file
        with open(os.path.join(project_dir, 'build.gradle'), 'w') as build_file:
            build_file.write(build_gradle_content)

    def __execute_gradle(self, staging_dir:str, project_dir:str, gradle_repository_closure:str, artifact_group:str, artifact_name:str, artifact_version:str):
        """(private) 
        Executes a custom task, resolveAllDependencies, to perform the actual retrieval of artifacts.

        Args:
            staging_dir (str): directory where the gradle project is to be staged
            project_dir (str): directory of the gradle project is to be created
            gradle_repository_closure (str): identifies the location where the aritfact should be retrieved from
            artifact_group (str): group from the Maven GAV parameters
            artifact_name (str): artifact from the Maven GAV parameters
            artifact_version (str): version from the Maven GAV parameters

        Raises:
            ArtifactNotFoundError: if the artifact could not be found in the repository
            ArtifactNotResolvableError: if the repository was unable to resolve the location where the artifact should be
        """

        self.__create_minimal_gradle_project(project_dir, gradle_repository_closure, artifact_group, artifact_name, artifact_version)

        # These are not necessary for every call, but opting to set them here once and then 
        # not have special logic or duplicate code to handle when retrieving against authenticated
        # repositories
        env = os.environ.copy()
        env['username'] = self.user
        env['password'] = self.token

        # Run 'gradle dependencies' to list dependencies
        result = subprocess.run(['gradle', 'resolveAllDependencies', 
                                '--gradle-user-home', staging_dir,
                                f"-Dhttp.proxyHost={self.proxy_host}",
                                f"-Dhttp.proxyPort={self.proxy_port}",
                                f"-Dhttps.proxyHost={self.proxy_host}",
                                f"-Dhttps.proxyPort={self.proxy_port}"], 
                                env=env, cwd=project_dir, text=True, capture_output=True)
        
        if result.returncode != 0:
            stderr_lines = result.stderr.splitlines()

            # This first 'Could not find' explicitly looks for the .jar extension as sometime -parent do not have sources
            # they are strictly pom files
            artifact_not_found = any(f'Could not find {artifact_name}-{artifact_version}.jar' in line for line in stderr_lines)
            artifact_not_available = any(f'Could not find {artifact_name}:{artifact_name}:{artifact_version}' in line for line in stderr_lines)
            artifact_not_resolvable = any(f'Could not resolve {artifact_name}:{artifact_name}:{artifact_version}' in line for line in stderr_lines)

            if artifact_not_found:
                raise ArtifactNotFoundError(f"Unable to locate the requested artifact: {artifact_name}-{artifact_version}")
            elif artifact_not_available or artifact_not_resolvable:
                raise ArtifactNotResolvableError(f"Unable to resolve the requested artifact: {artifact_name}-{artifact_version}")

    def __get_dependencies(self, staging_dir:str, project_dir:str, artifact_group:str, artifact_name:str, artifact_version:str, artifact_type:str):
        """(private) 
        Retrieves the dependencies by executing a custom task, resolveAllDependencies, to perform the actual retrieval of artifacts.
        This will retrieve artifacts from the 'public repository (e.g., mavenCentral) and store the in self.artifacts

        Args:
            staging_dir (str): directory where the gradle project is to be staged
            project_dir (str): directory of the gradle project is to be created
            artifact_group (str): group from the Maven GAV parameters
            artifact_name (str): artifact from the Maven GAV parameters
            artifact_version (str): version from the Maven GAV parameters
            artifact_type (str): type of artifact (e.g., jar or pom)
        """
        
        gradle_repository_closure = f"repositories {{ maven {{ url '{self.public_repo}'}} }}"

        # This intentionally doesn't catch the exceptions so that the error can boil up to the top
        # if we are missing artifacts at this level then lighthouse will never be able to obtain them
        self.__execute_gradle(staging_dir, project_dir, gradle_repository_closure, artifact_group, artifact_name, artifact_version)
        
        # Adding the type here rather than assuming jar aids in finding all the
        # parent pom files
        artifact_package_name = f"{artifact_name}-{artifact_version}.{artifact_type}"

        approved = False
        status = 'Needs Requested'
        location = 'Not Available'
        
        available = self.locator.is_artifact_trusted(artifact_group, artifact_name, artifact_version, artifact_package_name)
        lighthouse_cache = f"{self.lighthouse_repo.strip('/')}-cache"
        if self.locator.is_artifact_available(lighthouse_cache, artifact_group, artifact_name, artifact_version, artifact_package_name) == True and available == False:
            status = 'Known: Needs Copied'
            approved = True
        elif available == True:
            approved = True
            status = 'Known: Trusted'
            location = f"{self.program_trusted_repo.rstrip('/')}/{artifact_group.replace('.','/')}/{artifact_name}/{artifact_version}/"
        elif self.locator.is_artifact_untrusted(artifact_group, artifact_name, artifact_version, artifact_package_name) == True:
            status = 'Known: Untrusted'
            location = f"{self.program_untrusted_repo.rstrip('/')}/{artifact_group.replace('.','/')}/{artifact_name}/{artifact_version}/"
        
        artifacts_in_staging = self.__locate_artifacts_in_staging(artifact_group, artifact_name, artifact_version)
        
        artifact = {
            "group": artifact_group,
            "artifact": artifact_name,
            "version": artifact_version,
            "status": status,
            "approved": approved,
            "artifacts": artifacts_in_staging,
            "location" : location
            }

        self.artifacts[f"{artifact_name}:{artifact_version}"] = artifact

    def __process_dependencies(self):
        """(private) 
        Process the list of dependencies associated with the requested artifact. This 
        recursivily identifies all necessary artifacts.
        """

        inventory_staging_dir = f"{self.staging_dir}/inventory"
        original_cwd = os.getcwd()
        os.chdir(inventory_staging_dir)
        
        # This split into three because it will allow us to tell the difference between the types
        # and it will dictate that we process all jars first, that way if we have a pom only we don't
        # accidentially try to process it as a jar.
        self.__proccess_inventory(f"{inventory_staging_dir}/caches/modules-2/files-2.1/**/*.jar", inventory_staging_dir, 'jar')
        self.__proccess_inventory(f"{inventory_staging_dir}/caches/modules-2/files-2.1/**/*.pom", inventory_staging_dir, 'pom')
        self.__proccess_inventory(f"{inventory_staging_dir}/caches/modules-2/files-2.1/**/*.bom", inventory_staging_dir, 'bom')
        
        os.chdir(original_cwd)
               
          
    def __proccess_inventory(self, pattern:str, inventory_staging_dir:str, type:str):
        all_matching_artifacts = [os.path.abspath(file) for file in glob.glob(pattern, recursive=True)]
        for path in all_matching_artifacts:
            path_to_sha1 = os.path.dirname(path)
            path_to_version = os.path.dirname(path_to_sha1)
            artifact_version = os.path.basename(path_to_version)
            path_to_artifact = os.path.dirname(path_to_version)
            artifact_name = os.path.basename(path_to_artifact)
            path_to_group = os.path.dirname(path_to_artifact)
            artifact_group = os.path.basename(path_to_group)

            if f"{artifact_name}:{artifact_version}" not in self.artifacts:
                project_name = f"{artifact_name}-dependency-checker"
                project_dir = os.path.join(inventory_staging_dir, project_name)
                self.__get_dependencies(inventory_staging_dir, project_dir, artifact_group, artifact_name, artifact_version, type)
                self.__process_dependencies()
                        
    def __locate_artifacts_in_staging(self, artifact_group:str, artifact_name:str, artifact_version:str):
        """(private)
        Locates artifacts that were retrieved and stored in the inventory.

        Args:
            artifact_group (str): group from the Maven GAV parameters
            artifact_name (str): artifact from the Maven GAV parameters
            artifact_version (str): version from the Maven GAV parameters

        Returns:
            list: all artifacts in the inventory that match *.jar, *.pom, *.bom, or *.module
        """
        
        original_cwd = os.getcwd()
        os.chdir(f"{self.staging_dir}/inventory")

        all_jar_paths = glob.glob(f"**/{artifact_group}/{artifact_name}/{artifact_version}/**/*.jar", recursive=True)
        all_pom_paths = glob.glob(f"**/{artifact_group}/{artifact_name}/{artifact_version}/**/*.pom", recursive=True)
        all_bom_paths = glob.glob(f"**/{artifact_group}/{artifact_name}/{artifact_version}/**/*.bom", recursive=True)
        all_module_paths = glob.glob(f"**/{artifact_group}/{artifact_name}/{artifact_version}/**/*.module", recursive=True)
        
        all_artifacts = [os.path.abspath(file) for file in all_jar_paths + all_pom_paths + all_module_paths + all_bom_paths]

        os.chdir(original_cwd)

        return all_artifacts