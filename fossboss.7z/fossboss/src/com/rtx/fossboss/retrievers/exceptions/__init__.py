# RAYTHEON PROPRIETARY
# This document contains data or information proprietary to Raytheon Company
# and is restricted to use only by persons authorized by Raytheon Company in
# writing to use it. Disclosure to unauthorized persons would likely cause
# substantial competitive harm to Raytheon Company's business position.
# Neither said document nor its contents shall be furnished or disclosed to or
# copied or used by persons outside Raytheon Company without the express
# written approval of Raytheon Company.
# 
# Unpublished Work - Copyright Raytheon Company