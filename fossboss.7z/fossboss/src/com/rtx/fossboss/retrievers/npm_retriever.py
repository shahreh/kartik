 # RAYTHEON PROPRIETARY
 # This document contains data or information proprietary to Raytheon Company
 # and is restricted to use only by persons authorized by Raytheon Company in
 # writing to use it. Disclosure to unauthorized persons would likely cause
 # substantial competitive harm to Raytheon Company's business position.
 # Neither said document nor its contents shall be furnished or disclosed to or
 # copied or used by persons outside Raytheon Company without the express
 # written approval of Raytheon Company.
 # 
 # Unpublished Work - Copyright Raytheon Company

import logging as log
import re
import requests
import subprocess
import os
import traceback

from jinja2 import Template

from com.rtx.fossboss.retrievers._retriever import Retriever
from com.rtx.fossboss.retrievers.exceptions.authentication_error import AuthenticationError
import com.rtx.fossboss.utils.npm_version_parser as npm_version_parser

logger = log.getLogger('npm-retriever-logger')
logger.setLevel(log.ERROR)

class NpmRetriever(Retriever):

    def generate_inventory(self):
        """
        Identifies all the dependencies of the desired artifact by inspecting the package-info.json form 
        https://registry.npmjs.org. At the close of this function, self.artfacts will have a complete 
        listing of artifacts that will need to be submitted to Lighthouse/FOSS ES.
        """

        # Process all the dependencies from the product's package-info.json. Note: this call is 
        # recurisve to ensure all the dependencies of dependencies are also retrieved.
        package_info = self.__get_package_info(self.artifact_name, self.artifact_version)
        self.__process_dependencies(package_info)

    def retrieve_from_internet(self):
        """
        Retrieves the desired artifact and all its dependencies from https://registry.npmjs.org. At the end 
        of this function call, self.artfacts will have a complete listing of artifacts that will need to be
        submitted to Lighthouse/FOSS ES. All artifacts will be initially set as unapproved.
        """
        
        # Download the artifact(s) that is being requested
        for artifact in self.artifacts.values():
            if artifact["approved"] == False:
                self.__download_package(artifact["artifact"], artifact["version"])
        
    def retrieve_from_lighthouse(self):
        self.trusted_install_dir = f"{self.staging_dir}/trusted"
        os.makedirs(self.trusted_install_dir)
        
        self.__generate_npmrc_file(self.token, self.lighthouse_repo)

        # Call to npm init will create the package.json file which is required by npm pack command
        result = subprocess.run([
            "npm", "init", "-y"
        ], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, cwd=self.trusted_install_dir)

        if result.returncode != 0:
            logger.error(result.stdout)
            logger.error(result.stderr)
            raise RuntimeError("npm init failed")
           
        for key, value in self.artifacts.items():
            
            # downloads a package as a .tgz
            result = subprocess.run([
                "npm", 
                "pack", 
                key.replace(":", "@"),
                "--registry",
                self.lighthouse_repo
            ], text=True, capture_output=True, cwd=self.trusted_install_dir)
            
            logger.debug(f"Return code from npm pack for {key}: {result.returncode}")
            logger.debug("npm pack output:")
            logger.debug(result.stdout)
            logger.debug(result.stderr)

            if result.returncode != 0:
                stderr_lines = result.stderr.splitlines()
                e401_error = any(f'code E401' in line for line in stderr_lines)
                e403_error = any(f'code E403' in line for line in stderr_lines)
                if e401_error == True:
                    raise AuthenticationError(f"Authentication error, E401, communicating with {self.lighthouse_repo}. Please verify the .npmrc file is present and contains and entry for the registry.")
                elif e403_error == True:
                    raise AuthenticationError(f"Authentication error, E403, communicating with {self.lighthouse_repo}. Please verify the auth token in the .npmrc file is valid.")
                else:
                    value["status"] = 'Requested'
                    value["approved"] = False
                    logger.debug(f"Unable to successfully install {key} from lighthouse. This is to be expected when making initial requests.")
            else:
                value["status"] = 'Requested'
                value["approved"] = True
                value["artifacts"] = [f"{self.trusted_install_dir}/{key.replace(':','-')}.tgz"]
        
        logger.debug(f"Artifact list after retrieval from lighthouse:\n{self.artifacts}")

    def upload_artifacts(self, early_access_waiver:bool=True):
        
        for key, value in self.artifacts.items():
            if value["status"] == 'Requested'  and value["approved"] == True:
                location = self.publisher.publish_via_upload(self.program_trusted_repo, None, value['artifact'], '-', value['artifacts'])
                value['location'] = location
            elif early_access_waiver == True:
                artifacts = [f"{self.staging_dir}/untrusted/{key.replace(':','-')}.tgz"]
                location = self.publisher.publish_via_upload(self.program_untrusted_repo, None, value['artifact'], '-', artifacts)
                value['location'] = location
    
    def __get_package_info(self, artifact_name, artifact_version):

        request_url = f"{self.public_repo}/{artifact_name}/{artifact_version}"
        logger.debug(f"__get_package_info request url: {request_url}")
        response = requests.get(request_url, verify=self.ca_bundle)
        if response.status_code == 200:
            artifact = {
                "artifact": artifact_name,
                "version": artifact_version,
                "status": "Unknown",
                "approved": False,
                "artifacts": [],
                "location": "Not Available"
                }
            self.artifacts[f"{artifact_name}:{artifact_version}"] = artifact
            return response.json()
        else:
            logger.error()
            raise Exception(f"Failed to get package info: {response.status_code}")
        
    def __download_package(self, artifact_name, artifact_version):
        os.makedirs(f"{self.staging_dir}/untrusted", exist_ok=True)
        request_url = f"{self.public_repo}/{artifact_name}/-/{artifact_name}-{artifact_version}.tgz"
        logger.debug(f"__download_package request url: {request_url}")
        response = requests.get(request_url, stream=True, verify=self.ca_bundle)
        if response.status_code == 200:
            with open(f"{self.staging_dir}/untrusted/{artifact_name}-{artifact_version}.tgz", 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)
            
            artifact = {
                "artifact": artifact_name,
                "version": artifact_version,
                "status": "Unknown",
                "approved": False,
                "artifacts": [f"{self.staging_dir}/untrusted/{artifact_name}-{artifact_version}.tgz"],
                "location": "Not Available"
                }        
            
            self.artifacts[f"{artifact_name}:{artifact_version}"] = artifact
        else:
            raise Exception(f"Failed to download package: {response.status_code}")
        
    def __process_dependencies(self, package_info):
        dependencies = package_info.get("dependencies", {})
        for dep, version in dependencies.items():
            try:
                version = npm_version_parser.get_latest_applicable_version(self.public_repo, dep, version)

                if f"{dep}:{version}" not in self.artifacts:
                    package_info = self.__get_package_info(dep, version)
                    self.__process_dependencies(package_info)

                self.__download_package(dep, version)
                    
            except Exception as e:
                traceback.print_exc()
                logger.error(f"Error processing {dep}@{version}: {str(e)}")

    def __extract_minimum_version(self, constraint):
        
        matches = re.findall(r'>=?\s*(\d+\.\d+(?:\.\d+)?(?:-[\w.]+)?(?:\+[\w.]+)?)', constraint)
        if matches:
            return matches[0]
        return None
    
    def __generate_npmrc_file(self, token:str, registry:str):
        
        pattern = r"(https://.*/api/npm)"
        match = re.match(pattern, registry)
        if match:
            base_api_npm = match.group(1)
            
        result = subprocess.run([
                "curl", 
                "-u", 
                f":{token}",
                f"{base_api_npm}/auth"
                
            ], text=True, capture_output=True)
        
        for line in result.stdout.splitlines():
            if '_auth' in line:
                token = line.split(' ')[2]
                break
        
        base_path = os.path.dirname(__file__) 
        template_path = os.path.join(base_path, 'jinja_templates/npmrc.j2')
        with open(template_path) as file:
            template = Template(file.read())

        content = {
            "registry": registry,
            "token": token
        }
        
        rendered_npmrc = template.render(content)
        
        with open(f"{self.trusted_install_dir}/.npmrc", "w") as file:
            file.write(rendered_npmrc)
