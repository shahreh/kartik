# RAYTHEON PROPRIETARY
# This document contains data or information proprietary to Raytheon Company
# and is restricted to use only by persons authorized by Raytheon Company in
# writing to use it. Disclosure to unauthorized persons would likely cause
# substantial competitive harm to Raytheon Company's business position.
# Neither said document nor its contents shall be furnished or disclosed to or
# copied or used by persons outside Raytheon Company without the express
# written approval of Raytheon Company.
# 
# Unpublished Work - Copyright Raytheon Company

import logging as log
import requests
import re
from packaging.version import Version, InvalidVersion

logger = log.getLogger('public-locator-logger')
logger.setLevel(log.ERROR)

class PublicLocator:

    def __init__ (self, public_repository: str, ca_bundle: str, type: str):
        self.public_repository = public_repository.rstrip('/')
        self.ca_bundle = ca_bundle

        if 'npm' == type:
            self.url_context_formatter = NpmUrlContextFormatter()
        elif 'pypi' == type:
            self.url_context_formatter = PypiUrlContextFormatter()
        elif 'maven' == type:
            self.url_context_formatter = MavenUrlContextFormatter()
        else:
            raise ValueError(f"Unsupported technology type: {type}")
        self.type = type

    def is_artifact_available(self, artifact_group: str, artifact_name: str, artifact_version: str, artifact_package_name: str):
        """
        Determines if an artifact is available in the specified public repository using a standard REST approach.
        In many cases, the URL that determines if it is available is not the same as the registry.
        If this is the case, it is expected that a URL context formatter be utilized.

        Args:
            artifact_group (str): Group from the GAV parameters.
            artifact_name (str): Artifact from the GAV parameters.
            artifact_version (str): Version from the GAV parameters.
            artifact_package_name (str): Specific package that is being located.

        Returns:
            boolean: Returns True if the artifact can be successfully located, otherwise False.
        """
        if not self.public_repository or not artifact_name:
            return False

        url = self.url_context_formatter.format(self.public_repository, artifact_group, artifact_name, artifact_version)

        # If a specific package was provided, be sure to add it to the URL. 
        if artifact_package_name:
            url = f"{url}/{artifact_package_name}"

        logger.debug(f"{url}")

        response = requests.get(url, verify=self.ca_bundle)

        return response.status_code == 200

    def get_latest_version(self, artifact: str, major_version: str):
        """
        Finds the latest version of the given artifact within the specified major version.

        Args:
            artifact (str): The artifact name.
            major_version (str): The major version.

        Returns:
            str: The latest version within the specified major version.
        """
        if self.type == 'maven':
            return self.get_latest_maven_version(artifact, major_version)
        elif self.type == 'npm':
            return self.get_latest_npm_version(artifact, major_version)
        elif self.type == 'pypi':
            return self.get_latest_pypi_version(artifact, major_version)
        else:
            raise ValueError(f"Unsupported technology type: {self.type}")

    def get_latest_maven_version(self, artifact: str, major_version: str):
        group, artifact_name = artifact.rsplit('.', 1)
        group_path = group.replace('.', '/')
        url = f"{self.public_repository}/{group_path}/{artifact_name}/maven-metadata.xml"

        response = requests.get(url, verify=self.ca_bundle)
        if response.status_code != 200:
            raise ValueError(f"Failed to fetch metadata for {artifact}: {response.status_code}")

        versions = re.findall(r'<version>(.*?)</version>', response.text)
        return self.find_latest_version(versions, major_version)

    def get_latest_npm_version(self, artifact: str, major_version: str):
        url = f"{self.public_repository}/{artifact}"

        response = requests.get(url, verify=self.ca_bundle)
        if response.status_code != 200:
            raise ValueError(f"Failed to fetch metadata for {artifact}: {response.status_code}")

        data = response.json()
        versions = data.get('versions', {}).keys()
        return self.find_latest_version(versions, major_version)

    def get_latest_pypi_version(self, artifact: str, major_version: str):
        url = f"{self.public_repository}/{artifact}/json"

        response = requests.get(url, verify=self.ca_bundle)
        if response.status_code != 200:
            raise ValueError(f"Failed to fetch metadata for {artifact}: {response.status_code}")

        data = response.json()
        versions = data.get('releases', {}).keys()
        return self.find_latest_version(versions, major_version)

    def find_latest_version(self, versions, major_version):
        latest_version = None
        major_version_pattern = re.compile(rf'^{major_version}\.')

        for version in versions:
            if major_version_pattern.match(version):
                try:
                    version_obj = Version(version)
                    if latest_version is None or version_obj > latest_version:
                        latest_version = version_obj
                except InvalidVersion:
                    continue

        return str(latest_version) if latest_version else None

class UrlContextFormatter:
    def format(self, repository, artifact_group, artifact_name, artifact_version) -> str:
        raise NotImplementedError("Technology specific locators must implement this method")

class MavenUrlContextFormatter(UrlContextFormatter):
    def format(self, repository, artifact_group, artifact_name, artifact_version) -> str:
        return f"{repository}/{artifact_group.replace('.','/')}/{artifact_name}/{artifact_version}"
    
class NpmUrlContextFormatter(UrlContextFormatter):
    def format(self, repository, artifact_group, artifact_name, artifact_version) -> str:
        return f"{repository}/{artifact_name}/{artifact_version}"
    
class PypiUrlContextFormatter(UrlContextFormatter):
    def format(self, repository, artifact_group, artifact_name, artifact_version) -> str:
        # Strip off the last '/' to allow compact coding and checking for existence
        return f"{repository.replace('simple', 'project').rstrip('/')}/{artifact_name}/{artifact_version}"