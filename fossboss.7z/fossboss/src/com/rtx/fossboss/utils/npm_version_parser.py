# RAYTHEON PROPRIETARY
# This document contains data or information proprietary to Raytheon Company
# and is restricted to use only by persons authorized by Raytheon Company in
# writing to use it. Disclosure to unauthorized persons would likely cause
# substantial competitive harm to Raytheon Company's business position.
# Neither said document nor its contents shall be furnished or disclosed to or
# copied or used by persons outside Raytheon Company without the express
# written approval of Raytheon Company.
# 
# Unpublished Work - Copyright Raytheon Company

import subprocess
import json
import logging as log

from version_parser.version import Version

logger = log.getLogger('npm-version-parser-logger')
logger.setLevel(log.ERROR)

def get_applicable_versions(public_repo, artifact_name, constraints='*'):
    """
    Retrieve from npmjs.org a list of versions for the artifact that fit the constraints. 

    Args:
        artifact_name (str): npm package name
        constraints (str): optional npm-style version constraints Ex. "^3.0.0 || 4.0.x"
        public_repo (str): repo from which to check available versions 

    Returns:
        list[str]: list of versions found that fit the constraints

    Raises:
        RuntimeError: if the npm view subprocess indicates unsuccessful return code 
    """

    applicable_versions = list()

    # npm view retrieves all details about versions fitting the given constraints 
    # Assumption: Currently assumes public_repo does not require credentials. 
    #   If false, then there would need to be a valid .npmrc in the working 
    #   directory this subprocess runs from.
    result = subprocess.run([
        "npm", 
        "view", 
        f"{artifact_name}@{constraints}", 
        "version", 
        "--json",
        "--registry", public_repo
    ], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

    if result.returncode != 0:
        logger.error(result.stdout)
        logger.error(result.stderr)
        raise RuntimeError("npm view failed")

    return json.loads(result.stdout)

def get_latest_applicable_version(public_repo, artifact_name, constraints='*'):
    """
    Retrieve from npmjs.org a list of versions for the artifact that fit the constraints. 

    Args:
        artifact_name (str): npm package name
        constraints (str): optional npm-style version constraints Ex. "^3.0.0 || 4.0.x"
        public_repo (str): repo from which to check available versions

    Returns:
        str: latest version of the given package while adherring to the given constraints

    Raises:
        RuntimeError: if the npm view subprocess indicates unsuccessful return code 
    """

    candidates = get_applicable_versions(public_repo, artifact_name, constraints)

    logger.debug(f"Applicable versions for {artifact_name}: {candidates}")

    if len(candidates) > 0:
        latest_version = candidates[0]
        for candidate in candidates:
            if Version(candidate) > Version(latest_version):
                latest_version = candidate
    
        logger.debug(f"Latest applicable version for {artifact_name}: {latest_version}")
        return latest_version
    else:
        raise RuntimeError(f"No applicable versions found: {artifact_name}@{constraints}")
    