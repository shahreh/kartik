 # RAYTHEON PROPRIETARY
 # This document contains data or information proprietary to Raytheon Company
 # and is restricted to use only by persons authorized by Raytheon Company in
 # writing to use it. Disclosure to unauthorized persons would likely cause
 # substantial competitive harm to Raytheon Company's business position.
 # Neither said document nor its contents shall be furnished or disclosed to or
 # copied or used by persons outside Raytheon Company without the express
 # written approval of Raytheon Company.
 # 
 # Unpublished Work - Copyright Raytheon Company

import logging as log

from jinja2 import Template

from com.rtx.fossboss.formatters._formatter import Formatter

logger = log.getLogger('jinja-formatter-logger')
logger.setLevel(log.ERROR)

class JinjaFormatter(Formatter):

    def __init__(self, key: str, artifacts: dict, jinja_template:str) -> None:
        self.jinja_template = jinja_template
        super().__init__(key, artifacts)

    def format(self, key:str, artifacts:dict) -> str:

        template = Template(self.jinja_template)

        content = {
            "key": key,
            "artifacts": artifacts
        }
        return template.render(data=content)