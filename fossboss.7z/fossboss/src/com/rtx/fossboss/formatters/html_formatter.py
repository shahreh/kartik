 # RAYTHEON PROPRIETARY
 # This document contains data or information proprietary to Raytheon Company
 # and is restricted to use only by persons authorized by Raytheon Company in
 # writing to use it. Disclosure to unauthorized persons would likely cause
 # substantial competitive harm to Raytheon Company's business position.
 # Neither said document nor its contents shall be furnished or disclosed to or
 # copied or used by persons outside Raytheon Company without the express
 # written approval of Raytheon Company.
 # 
 # Unpublished Work - Copyright Raytheon Company

import logging as log
import os

from jinja2 import Template

from com.rtx.fossboss.formatters._formatter import Formatter

logger = log.getLogger('html-formatter-logger')
logger.setLevel(log.ERROR)

class HtmlFormatter(Formatter):

    def __init__(self, key: str, artifacts: dict) -> None:
        super().__init__(key, artifacts)

    def format(self) -> str:

        # Referencing the file this way avoids issues with resolving it's location
        base_path = os.path.dirname(__file__) 
        template_path = os.path.join(base_path, 'templates/msf-notification-template.html.j2')
        with open(template_path) as file:
            template = Template(file.read())

        content = {
            "key": self.key,
            "artifacts": self.artifacts
        }

        logger.debug(f"html formatter content:\n{content}")

        return template.render(data=content)