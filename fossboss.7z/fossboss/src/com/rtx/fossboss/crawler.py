import argparse
import json
import logging as log
import sys
import uuid
from artifactory_locator import ArtifactoryLocator
from public_locator import PublicLocator

log.basicConfig(level=log.WARN, format="%(asctime)-15s %(levelname)s %(name)s: %(message)s")
logger = log.getLogger('fossboss-logger')
logger.setLevel(log.ERROR)

class Crawler:

    def __init__(self, user, token, ca_bundle, trusted_repo, untrusted_repo, tech_type):
        self.user = user
        self.token = token
        self.ca_bundle = ca_bundle
        self.trusted_repo = trusted_repo
        self.untrusted_repo = untrusted_repo
        self.tech_type = tech_type
        self.locator = ArtifactoryLocator(user, token, ca_bundle, trusted_repo, untrusted_repo)
        self.public_locator = PublicLocator(None, ca_bundle, tech_type)  # Set repo_url dynamically in filter_newer_versions

    def inventory_trusted(self):
        return self.locator.inventory_trusted()

    def inventory_untrusted(self):
        return self.locator.inventory_untrusted()

    def filter_newer_versions(self, inventory):
        filtered_inventory = {}
        for artifact, version in inventory.items():
            major_version = version.split('.')[0]
            repo_url = self.get_public_repo_url(artifact)  # Get correct repo URL based on artifact
            self.public_locator.public_repository = repo_url  # Set repo URL dynamically
            latest_version = self.public_locator.get_latest_version(artifact, major_version)
            if latest_version and Version(version) >= Version(latest_version):
                filtered_inventory[artifact] = version
        return filtered_inventory

    def get_public_repo_url(self, artifact):
        if self.tech_type == 'maven':
            return 'https://repo.maven.apache.org/maven2'
        elif self.tech_type == 'npm':
            return 'https://registry.npmjs.org'
        elif self.tech_type == 'pypi':
            return 'https://pypi.org/pypi'
        else:
            raise ValueError(f"Unsupported technology type: {self.tech_type}")

    def run(self, tech_type=None):
        inventory = {}
        if tech_type:
            if tech_type == 'maven':
                inventory.update(self.inventory_trusted())
            elif tech_type == 'npm':
                inventory.update(self.inventory_untrusted())
            elif tech_type == 'pypi':
                inventory.update(self.inventory_untrusted())
        else:
            inventory.update(self.inventory_trusted())
            inventory.update(self.inventory_untrusted())

        filtered_inventory = self.filter_newer_versions(inventory)
        self.output_inventory(filtered_inventory)
        self.output_anyfile(filtered_inventory)

    def output_inventory(self, inventory):
        with open('inventory.json', 'w') as f:
            json.dump(inventory, f, indent=4)

    def output_anyfile(self, inventory):
        with open('anyfile', 'w') as f:
            for artifact, version in inventory.items():
                if self.tech_type == 'maven':
                    f.write(f"{artifact.replace('.', '/')}/{version}\n")
                elif self.tech_type == 'npm':
                    f.write(f"npm:{artifact}@{version}\n")
                elif self.tech_type == 'pypi':
                    f.write(f"pypi-{artifact}-{version}\n")

def main():
    parser = argparse.ArgumentParser(description="Artifactory Crawler CLI")
    parser.add_argument('--user', required=True, help='Artifactory username')
    parser.add_argument('--token', required=True, help='Artifactory token')
    parser.add_argument("-ca", "--ca-bundle",
                        default="/etc/pki/ca-trust/extracted/pem/tls-ca-bundle.pem",
                        help="Bundle of trusted certificates.") 
    parser.add_argument('--trusted-repo', required=True, help='URL of the trusted repository')
    parser.add_argument('--untrusted-repo', required=True, help='URL of the untrusted repository')
    parser.add_argument('--type', choices=['maven', 'npm', 'pypi'], help='Technology type to crawl')

    args = parser.parse_args()

    crawler = Crawler(args.user, args.token, args.ca_bundle, args.trusted_repo, args.untrusted_repo, args.type)
    crawler.run(args.type)

if __name__ == '__main__':
    main()