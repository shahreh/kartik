# RAYTHEON PROPRIETARY
 # This document contains data or information proprietary to Raytheon Company
 # and is restricted to use only by persons authorized by Raytheon Company in
 # writing to use it. Disclosure to unauthorized persons would likely cause
 # substantial competitive harm to Raytheon Company's business position.
 # Neither said document nor its contents shall be furnished or disclosed to or
 # copied or used by persons outside Raytheon Company without the express
 # written approval of Raytheon Company.
 # 
 # Unpublished Work - Copyright Raytheon Company

import logging as log
import urllib.parse

from artifactory import ArtifactoryPath
from com.rtx.fossboss.locators._locator import Locator

logger = log.getLogger('artifactory-locator-logger')
logger.setLevel(log.ERROR)

class ArtifactoryLocator(Locator):
    
    def is_artifact_trusted(self, artifact_group:str, artifact_name:str, artifact_version:str, artifact_package_name:str) -> bool:
        return self.is_artifact_available(self.program_trusted_repository, artifact_group, artifact_name, artifact_version, artifact_package_name)

    def is_artifact_untrusted(self, artifact_group:str, artifact_name:str, artifact_version:str, artifact_package_name:str) -> bool:
        return self.is_artifact_available(self.program_untrusted_repository, artifact_group, artifact_name, artifact_version, artifact_package_name)

    def is_artifact_available(self, repository:str, artifact_group:str, artifact_name:str, artifact_version:str, artifact_package_name:str) -> bool:
        """
        Determines if an artifact is available by looking for the existence of the artifact within the reposiotry. If the artifact can be 
        'stat' then is determined to be available. This method can used to locate just the folder structure or can be used to locate an 
        exact artifct.

        Args:
            repository (str): repository where the artifact is expected to reside
            artifact_group (str): group from the GAV parameters
            artifact_name (str): artifact from the GAV parameters
            artifact_version (str): version from the GAV parameters
            artifact_package_name (str): specific package that is being located

        Returns:
            boolean: returns True if the artifact can be successfully located, otherwise False
        """
        
        if not repository:
            return False
        elif repository.endswith('/'):
            repository = repository.rstrip('/')
        
        url = None
        try:
            encoded_name = urllib.parse.quote(artifact_name)
            encoded_version = urllib.parse.quote(artifact_version)

            if artifact_group:
                encoded_group = urllib.parse.quote(artifact_group.replace('.','/'))
                url = f"{repository}/{encoded_group}/{encoded_name}/{encoded_version}/"
            else:
                url = f"{repository}/{encoded_name}/{encoded_version}/"

            # If looking for a specific artifact package, then add the package name
            # This valuable for any type that hold multiple aritfacts at the same level
            if artifact_package_name:
                url = f"{url}{artifact_package_name}"
            
            path = ArtifactoryPath(url, auth=(self.user, self.token), verify=self.ca_bundle)

            # Calling path.stat() will throw an exception if the artifact is not found. 
            # If it is found provides details on the artifact
            path.stat()
            return True
        except FileNotFoundError as fnfe:
            return False
        except Exception as e:
            logger.error(f"Unexpected error: {e}")
            return False
        
    def locate_artifact(self, repository:str, package_pattern:str) -> list:
        """
        Locates all the artifacts matching a pattern.

        Args:
            repository (str): target repository that is believe to contain the artifacts of interest
            package_pattern (str): pattern to search for; this will be placed in to a glob **/<pattern>

        Returns:
            list: list of all matching artifacts
        """

        matches = []
        
        base_repository_path = ArtifactoryPath(repository, auth=(self.user, self.token), verify=self.ca_bundle)
        for path in base_repository_path.glob(f'**/{package_pattern}'):
            matches.append(str(path))

        return matches
    

    def inventory_trusted(self) -> dict:
        return self.inventory_repository(self.program_trusted_repository)

    def inventory_untrusted(self) -> dict:
        return self.inventory_repository(self.program_untrusted_repository)

    def inventory_repository(self, repository: str) -> dict:
        inventory = {}
        try:
            base_repository_path = ArtifactoryPath(repository, auth=(self.user, self.token), verify=self.ca_bundle)
            for artifact_path in base_repository_path.glob('**/*'):
                if artifact_path.is_file():
                    artifact_name = artifact_path.name
                    artifact_version = self.extract_version(artifact_path)
                    inventory[artifact_name] = artifact_version
        except Exception as e:
            logger.error(f"Error inventorying repository: {e}")
            raise RuntimeError(f"Error inventorying repository {repository}: {e}")
        return inventory