# RAYTHEON PROPRIETARY
# This document contains data or information proprietary to Raytheon Company
# and is restricted to use only by persons authorized by Raytheon Company in
# writing to use it. Disclosure to unauthorized persons would likely cause
# substantial competitive harm to Raytheon Company's business position.
# Neither said document nor its contents shall be furnished or disclosed to or
# copied or used by persons outside Raytheon Company without the express
# written approval of Raytheon Company.
# 
# Unpublished Work - Copyright Raytheon Company

class Locator:
    def __init__ (self, lighthouse_repository:str, program_trusted_repository:str, 
                  program_untrusted_repository:str, user:str, token:str, ca_bundle:str):
        
        self.lighthouse_repository = lighthouse_repository.rstrip('/')
        self.program_trusted_repository = program_trusted_repository.rstrip('/')
        self.program_untrusted_repository = None if program_untrusted_repository is None else program_untrusted_repository.rstrip('/')
        self.user = user
        self.token = token
        self.ca_bundle = ca_bundle

    def is_artifact_trusted(self, artifact_group, artifact_name, artifact_version, artifact_package_name) -> bool:
        raise NotImplementedError("Technology specific locators must implement this method")

    def is_artifact_untrusted(self, artifact_group, artifact_name, artifact_version, artifact_package_name) -> bool:
        raise NotImplementedError("Technology specific locators must implement this method")
    
    def is_artifact_available(self, repository, artifact_group, artifact_name, artifact_version, artifact_package_name) -> bool:
        raise NotImplementedError("Technology specific locators must implement this method")
    
    def locate_artifact(self, repository:str, package_pattern:str):
        raise NotImplementedError("Technology specific locators must implement this method")