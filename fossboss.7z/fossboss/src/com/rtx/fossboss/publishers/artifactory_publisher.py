 # RAYTHEON PROPRIETARY
 # This document contains data or information proprietary to Raytheon Company
 # and is restricted to use only by persons authorized by Raytheon Company in
 # writing to use it. Disclosure to unauthorized persons would likely cause
 # substantial competitive harm to Raytheon Company's business position.
 # Neither said document nor its contents shall be furnished or disclosed to or
 # copied or used by persons outside Raytheon Company without the express
 # written approval of Raytheon Company.
 # 
 # Unpublished Work - Copyright Raytheon Company

import logging as log
import traceback
import urllib.parse

from artifactory import ArtifactoryPath
from com.rtx.fossboss.publishers._publisher import Publisher

logger = log.getLogger('publisher-logger')
logger.setLevel(log.ERROR)

class ArtifactoryPublisher(Publisher):
    
    def publish_via_copy_directory(self, source_repository:str, destination_repository:str, artifact_group:str, artifact_name:str, artifact_version:str) -> str:
        """
        Publishes a set of artifacts using Jfrog Artictory's built-in copy API. 

        Args:
            source_repository (str): location where the artifacts are currently stored
            destination_repository (str): location where the artifacts should be copied to
            artifact_group (str): group from the Maven GAV parameters
            artifact_name (str): artifact from the Maven GAV parameters
            artifact_version (str): version from the Maven GAV parameters

        Returns:
            path to the destination
        """

        # Encode for safety. This is required in the name as npm modules have @ in the name
        encoded_name = urllib.parse.quote(artifact_name)
        encoded_version = urllib.parse.quote(artifact_version)

        # Destination does not need the version folder as that folder will come over since it is the 
        # last directory of the source
        if artifact_group:
            encoded_group = urllib.parse.quote(artifact_group.replace('.','/'))
            source_path = f"{source_repository.rstrip('/')}/{encoded_group}/{encoded_name}/{encoded_version}"
            destination_path = f"{destination_repository.rstrip('/')}/{encoded_group}/{encoded_name}"
        else:
            source_path = f"{source_repository.rstrip('/')}/{encoded_name}/{encoded_version}"
            destination_path = f"{destination_repository.rstrip('/')}/{encoded_name}"
         
        destination = ArtifactoryPath(destination_path, auth=(self.user, self.token), verify=self.ca_bundle)
        destination.mkdir(exist_ok=True)
        
        source = ArtifactoryPath(source_path, auth=(self.user, self.token), verify=self.ca_bundle)   
        source.copy(destination, suppress_layouts=True)
        logger.debug(f"Successfully copied source {source} into the {destination}")

        return str(destination)

    def publish_via_copy_artifacts(self, destination_repository:str,  artifact_group:str, artifact_name:str, artifact_version:str, artifacts:list) -> str:
        """
        Publishes a set of artifacts using Jfrog Artictory's built-in copy API. 

        Args:
            destination_repository (str): location where the artifacts are to be copied to
            artifact_group (str): group from the Maven GAV parameters
            artifact_name (str): artifact from the Maven GAV parameters
            artifact_version (str): version from the Maven GAV parameters
            artifacts (list): list of direct paths to the artifacts that will be copied
        
        Returns:
            path to the destination
        """

        # Encode for safety. This is required in the name as npm modules have @ in the name
        encoded_name = urllib.parse.quote(artifact_name)
        encoded_version = urllib.parse.quote(artifact_version)

        if artifact_group:
            encoded_group = urllib.parse.quote(artifact_group.replace('.','/'))
            path = f"{destination_repository.rstrip('/')}/{encoded_group}/{encoded_name}/{encoded_version}"            
        else:
            path = f"{destination_repository.rstrip('/')}/{encoded_name}/{encoded_version}"
        
        destination = ArtifactoryPath(path,auth=(self.user, self.token), verify=self.ca_bundle)
        destination.mkdir(exist_ok=True)
        
        for artifact in artifacts:
            source = ArtifactoryPath(artifact, auth=(self.user, self.token), verify=self.ca_bundle)
            try:
                source.copy(destination, suppress_layouts=True)
                logger.debug(f"Successfully copied source {artifact} into the {destination}")
            except:
                logger.error(f"Error copying source {artifact} into the {destination}")

        return str(destination)
    
    def publish_via_upload(self, repository:str, artifact_group:str, artifact_name:str, artifact_version:str, artifacts:list) -> str:
        """
        Publishes a set of artifacts to the specified repository at the location identifyed by the GAV parameters. Note that
        artifact_group is optional. 

        Args:
            repository (str): location where the artifact should be deployed to
            artifact_group (str): group from the GAV parameters
            artifact_name (str): artifact from the GAV parameters
            artifact_version (str): version from the GAV parameters
            artifacts (list): list of artifacts (full path) that are to be uploaded

        Returns:
            path to the destination
        """

        # Encode for safety. This is required in the name as npm modules have @ in the name
        encoded_name = urllib.parse.quote(artifact_name)
        encoded_version = urllib.parse.quote(artifact_version)

        if artifact_group:
            encoded_group = urllib.parse.quote(artifact_group.replace('.','/'))
            path = f"{repository.rstrip('/')}/{encoded_group}/{encoded_name}/{encoded_version}"
        else:
            path = f"{repository.rstrip('/')}/{encoded_name}/{encoded_version}"
        
        logger.debug(path)

        destination = ArtifactoryPath(path,auth=(self.user, self.token), verify=self.ca_bundle)
        destination.mkdir(exist_ok=True)

        for artifact in artifacts:
            try:
                destination.deploy_file(artifact)
                logger.debug(f"Successfully uploaded {artifact}")
            except FileExistsError:
                logger.debug(f"File already exists for {artifact}")
            except Exception as e:
                logger.error(f"Error occurred deploying file, {artifact}")
                logger.error(traceback.format_exc())

        return str(destination)