 # RAYTHEON PROPRIETARY
 # This document contains data or information proprietary to Raytheon Company
 # and is restricted to use only by persons authorized by Raytheon Company in
 # writing to use it. Disclosure to unauthorized persons would likely cause
 # substantial competitive harm to Raytheon Company's business position.
 # Neither said document nor its contents shall be furnished or disclosed to or
 # copied or used by persons outside Raytheon Company without the express
 # written approval of Raytheon Company.
 # 
 # Unpublished Work - Copyright Raytheon Company

class Publisher:
    
    def __init__(self, user:str, token:str, ca_bundle:str):
        self.user = user
        self.token = token
        self.ca_bundle = ca_bundle

    def publish_via_copy_directory(self, source_repository:str, destination_repository:str, artifact_group:str, artifact_name:str, artifact_version:str) -> str:
        """
        Copies artifacts from the source_repository into the destination repository by copying the entire structure 
        found at the location of artifact_group/artifact_name/artifact_version. Note that artifact_group is optional.

        Args:
            source_repository (str): repositoriy where the artifacts are sourced from
            destination_repository (str): repository where the artifacts to are to be copied to
            artifact_group (str): group of the GAV parameters
            artifact_name (str): artifact of the GAV parameters
            artifact_version (str): version of the GAV parameters

        Returns:
            path to the destination
        """
        raise NotImplementedError("Technology specific publishers must implement this method")
    
    def publish_via_copy_artifacts(self, destination_repository:str, artifact_group:str, artifact_name:str, artifact_version:str, artifacts:list) -> str:
        """
        Copies the specified artifacts into the destination repository by sources the artifacts direct from their 
        identified path. They will be placed at the location of artifact_group/artifact_name/artifact_version. 

        Note: this function assumes all the artifacts belong to the same repository which also includes the destination. 
        This is an internal copy and *not* an upload.

        Args:
            destination_repository (str): repository where the artifacts to are to be copied to
            artifact_group (str): _optional_ group of the GAV parameters
            artifact_name (str): artifact of the GAV parameters
            artifact_version (str): version of the GAV parameters
            artifacts (list): list of fully qualified paths to artifacts within an artifact repository

        Returns:
            path to the destination
        """
        raise NotImplementedError("Technology specific publishers must implement this method")
        
    def publish_via_upload(self, destination_repository:str, artifact_group:str, artifact_name:str, artifact_version:str, artifacts:list) -> str:
        """
        Publishes a set of artifacts to the specified repository at the location identifyed by the GAV parameters. Note that
        artifact_group is optional. 

        Note: this function assumes the artifacts are stored on disk.

        Args:
            repository (str): location where the artifact should be deployed to
            artifact_group (str): group from the GAV parameters
            artifact_name (str): artifact from the GAV parameters
            artifact_version (str): version from the GAV parameters
            artifacts (list): list of artifacts (full path) that are to be uploaded
        
        Returns:
            path to the destination
        """
        raise NotImplementedError("Technology specific publishers must implement this method")