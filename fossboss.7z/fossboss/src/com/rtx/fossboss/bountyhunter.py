 # RAYTHEON PROPRIETARY
 # This document contains data or information proprietary to Raytheon Company
 # and is restricted to use only by persons authorized by Raytheon Company in
 # writing to use it. Disclosure to unauthorized persons would likely cause
 # substantial competitive harm to Raytheon Company's business position.
 # Neither said document nor its contents shall be furnished or disclosed to or
 # copied or used by persons outside Raytheon Company without the express
 # written approval of Raytheon Company.
 # 
 # Unpublished Work - Copyright Raytheon Company

import argparse
import json
import logging as log
import sys
import uuid

from com.rtx.fossboss.publishers.artifactory_publisher import ArtifactoryPublisher
from com.rtx.fossboss.retrievers.maven_retriever import MavenRetriever
from com.rtx.fossboss.retrievers.npm_retriever import NpmRetriever
from com.rtx.fossboss.retrievers.pypi_retriever import PypiRetriever
from com.rtx.fossboss.locators.artifactory_locator import ArtifactoryLocator
from com.rtx.fossboss.public_locator import PublicLocator
from com.rtx.fossboss.formatters.html_formatter import HtmlFormatter
from com.rtx.fossboss.formatters.jinja_formatter import JinjaFormatter
from com.rtx.fossboss.formatters.metrics_formatter import MetricsFormatter
from com.rtx.fossboss.utils.decorators import timed_execution

log.basicConfig(level=log.WARN, format="%(asctime)-15s %(levelname)s %(name)s: %(message)s")
logger = log.getLogger('fossboss-logger')
logger.setLevel(log.ERROR)

public_repository_map = {'maven':'https://repo.maven.apache.org/maven2/',
                         'npm':'https://registry.npmjs.org/',
                         'pypi':'https://pypi.org/simple/'}

def main():

    parser = argparse.parser = argparse.ArgumentParser("Initiates a request for a software product.")
    parser.add_argument("-t", "--type",
                        required=True, 
                        choices=["maven", "npm", "pypi"],
                        help="Identifies the type of artifact that is being requested.")
    
    parser.add_argument("-g", "--group", 
                        required=False, 
                        help="Optional parameter used to identify the artifacts group. This is most applicable to "
                        "retrieving artifacts from a maven repository")
    
    parser.add_argument("-a", "--artifact", 
                        required=True, 
                        help="Name of the artifact that is to be retrieved.")
    
    parser.add_argument("-v", "--version",
                        required=True, 
                        help="Version of the artifact that is to be retrieved")
    
    parser.add_argument("-u", "--user", 
                        required=True, 
                        help="User that initiates the call to the remote repository.")
    
    parser.add_argument("-tk", "--token", 
                        required=True, 
                        help="Token of the user initiating the request to the remote")

    parser.add_argument("-s", "--stage-dir", 
                        default="/tmp", 
                        help="Staging directory for retrievals and uploads.")
    
    parser.add_argument("-pr", "--public-repo", 
                        required=False,
                        help="URL of the public repository for the artifacts")

    parser.add_argument("-lr", "--lighthouse-repo", 
                        required=True,
                        help="URL of the repository that is connected to RTN FOSS ES (a.k.a. Lighthouse)")
    
    parser.add_argument("-ptr", "--program-trusted-repo", 
                        required=True,
                        help="URL of the program's repository for approvaed/trusted artifacts.")
    
    parser.add_argument("-pur", "--program-untrusted-repo", 
                        required=False,
                        help="URL of the program's repository for unapprovaed/untrusted artifacts.")
    
    parser.add_argument("-neaw", "--no-early-access-waiver",
                        action='store_true',
                        help="Indicator if the program is not operating with an early access waiver. If EAW is active, items not explicitly denied are "
                        "uploaded to the program's untrusted/unapproved artifact repository.")
    
    parser.add_argument("-ha", "--host-app",
                        default="artifactory",
                        choices=['artifactory', 'nexus'],
                        help="Specifies if the host application is Artifactory or Nexus")
    
    parser.add_argument("-ca", "--ca-bundle",
                        default="/etc/pki/ca-trust/extracted/pem/tls-ca-bundle.pem",
                        help="Bundle of trusted certificates.")

    parser.add_argument("-ph", "--proxy-host",
                        default="servproxygov.ray.com",
                        help="Output proxy host, used for both http/s")
    
    parser.add_argument("-pp", "--proxy-port",
                        default="80",
                        help="Output proxy port, used for both http/s")
    
    parser.add_argument("-of", "--output-format",
                        choices=['json', 'html', 'metrics', 'custom'],
                        default='json',
                        help="Determines the format that is written to standard out. If the option custom is choosen, the --jinja-template is required")
    
    parser.add_argument("-jt", "--jinja-template",
                        required=False,
                        help="The string contents of the jinja template that is used for format the output")

    parser.add_argument("-nc", "--no-clean",
                        action='store_true',
                        help="Do not clean temporary artifacts when exiting.")

    args = parser.parse_args()

    public_repo = public_repository_map[args.type]
    if args.public_repo:
        public_repo = args.public_repo

    publisher = None
    if args.host_app == 'artifactory':
        publisher = ArtifactoryPublisher(args.user, args.token, args.ca_bundle)
        locator = ArtifactoryLocator(args.lighthouse_repo, args.program_trusted_repo, 
                                     args.program_untrusted_repo, args.user, args.token, 
                                     args.ca_bundle)
    elif args.host_app == 'nexus':
        logger.error("Nexus is not officially supported at this time.")
        sys.exit(11)
    else:
        # The else failure code is 10, each else condition above will use a +1 approach for any unimplemented 
        # methods. Ideally this wouldn't really be any.
        logger.error(f"No class found that satisfies the implementation for {args.host_app} host application.")
        sys.exit(10)

    # If the artifact cannot be found in the public domain, then it's not going to be found by 
    # FOSS ES / Lighthouse either in which case we can exit and let the requester know.
    public_locator = PublicLocator(public_repo, args.ca_bundle, args.type)
    if public_locator.is_artifact_available(args.group, args.artifact, args.version, None) == False:
        logger.error(f"{args.artifact}@{args.version} could not be found in the public repository, {public_repo}")
        sys.exit(42)

    staging_dir = f"{args.stage_dir}/bountyhunter-{uuid.uuid4()}"
        
    retriever = None
    if args.type == "maven":
        retriever = MavenRetriever(args.group, args.artifact, args.version, public_repo, args.lighthouse_repo, 
                                   args.program_trusted_repo, args.program_untrusted_repo,
                                   staging_dir, locator, publisher, args.user, args.token,
                                   args.proxy_host, args.proxy_port, args.ca_bundle)
    elif args.type == "npm":
        retriever = NpmRetriever(None, args.artifact, args.version, public_repo, args.lighthouse_repo, 
                                 args.program_trusted_repo, args.program_untrusted_repo,
                                 staging_dir, locator, publisher, args.user, args.token,
                                 args.proxy_host, args.proxy_port, args.ca_bundle)
    elif args.type == "pypi":
        retriever = PypiRetriever(None, args.artifact, args.version, public_repo, args.lighthouse_repo, 
                                  args.program_trusted_repo, args.program_untrusted_repo,
                                  staging_dir, locator, publisher, args.user, args.token,
                                  args.proxy_host, args.proxy_port, args.ca_bundle)
    else:
        # The else failure code is 50, each else condition above will use a +1 approach for any unimplemented 
        # methods. Ideally this wouldn't really be any.
        logger.error(f"No class found that satisfies the implementation for {args.type} artifacts.")
        sys.exit(50)
    
    with timed_execution("total"):

        try:
            with timed_execution("gathering inventory"):
                retriever.generate_inventory()
            
            # After generating the inventory, first look to FOSS to see what can be automatically approved. Inspecting FOSS ES /
            # Lighthouse avoids downloading artifacts the internet to the greatest extent.
            with timed_execution("requesting from lighthouse"):
                retriever.retrieve_from_lighthouse()

            # The second step in retrieving FOSS through the automated approval process is submitting each item that was identified 
            # when looking at the internet through the FOSS ES process. This helps expedite the approvals by not waiting on a tiered 
            # approach to find the transitives of transitives. 
            with timed_execution("requesting from internet"):
                retriever.retrieve_from_internet()

            # The final functional step in retrieving FOSS through the automated approval process is uploading the artifacts into the 
            # program's local repositoies where it can they be consumed by others.
            with timed_execution("uploading artifacts"):
                early_access_waiver = not args.no_early_access_waiver
                retriever.upload_artifacts(early_access_waiver)

        finally:
            # Clean up any resources that were created as part of the retrieval process
            if not args.no_clean:
                with timed_execution("cleaning up staged area"):
                    retriever.clean()

    # Write the artifacts dict to standard out so it can be consumed by the calling process.
    if args.output_format == 'json':
        sys.stdout.write(json.dumps(retriever.artifacts, indent=4))
    elif args.output_format == 'html':
        sys.stdout.write(HtmlFormatter(f"{args.artifact}:{args.version}", retriever.artifacts).format())
    elif args.output_format == 'metrics':
        sys.stdout.write(MetricsFormatter(f"{args.artifact}:{args.version}", retriever.artifacts).format())
    elif args.output_format == 'custom':
        if not args.jinja_template:
            logger.error(f"Custom output was specified, but no --jinja-template was provided")
            sys.exit(100)
        else:
            sys.stdout.write(JinjaFormatter(f"{args.artifact}:{args.version}", retriever.artifacts, args.jinja_template).format())
        

if __name__ == "__main__":
    main()